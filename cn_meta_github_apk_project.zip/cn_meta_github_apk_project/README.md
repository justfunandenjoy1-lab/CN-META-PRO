# CN META PRO v4.0 — Stock Metadata Studio (Android APK + Web App)

**ফ্রি এপিআই, পেইড এপিআই এবং লোকাল এআই (Local AI) দিয়ে সকল স্টক সাইটের অফিসিয়াল নিয়ম অনুযায়ী মেটাডাটা তৈরি ও ইম্বেড করার পূর্ণাঙ্গ এন্ড্রয়েড অ্যাপ ও ওয়েব স্টুডিও।**

---

## প্রধান বৈশিষ্ট্যসমূহ (Key Features)

1. **Free, Paid & Local AI API সাপোর্ট:**
   - **ফ্রি ক্লাউড এপিআই (Free APIs):** Google Gemini (`gemini-2.5-flash`, `gemini-2.0-flash`), Groq Cloud (`llama-4-scout`, `llama-3.2-vision`), OpenRouter (Free Vision models), Mistral (`pixtral-12b`).
   - **পেইড ক্লাউড এপিআই (Paid APIs):** OpenAI (`gpt-4o-mini`, `gpt-4o`), Anthropic Claude (`claude-3-5-sonnet`), Together AI / DeepSeek / Custom OpenAI endpoints.
   - **লোকাল এআই (Local AI & Offline):**
     - **Ollama Native API (`/api/chat`):** পিসি (`127.0.0.1:11434`), ওয়াইফাই ল্যান (`192.168.x.x:11434`), কিংবা মোবাইলের Termux-এ চলা যেকোনো ভিশন মডেল (`llava`, `llama3.2-vision`, `moondream`, `qwen2.5vl`)।
     - **LM Studio / LocalAI / KoboldCPP (`/v1/chat/completions`):** যেকোনো লোকাল OpenAI-compatible সার্ভার।
     - **On-Device Offline Smart Engine:** ইন্টারনেট বা এপিআই ছাড়াই ছবির রঙ, আলো, কম্পোজিশন ও ফাইলনেম বিশ্লেষণ করে স্টক সাইটের নিয়ম মেনে টাইটেল ও কীওয়ার্ড তৈরির সুবিধা।

2. **১১টি স্টক সাইটের অফিসিয়াল নিয়ম ও CSV ফরম্যাট (Official Stock Agency Compliance):**
   - **Adobe Stock** (Max 200 chars title, Max 49 keywords, Category 1–21, Top 10 keyword priority)
   - **Shutterstock** (Description ≤ 200 chars, 7–50 keywords, 1–2 official Categories)
   - **Freepik** (Semicolon `;` separated CSV, Title ≤ 100 chars, Max 50 keywords, AI Prompt column)
   - **Vecteezy** (Filename, Title, Description, 5–50 Keywords)
   - **Getty Images / iStock ESP**
   - **Pond5** (Title ≤ 80 chars, Max 50 keywords)
   - **Depositphotos, Dreamstime, Alamy (Super Tags + Tags), 123RF, Miricanvas** এবং **Custom CSV Template**।
   - **All-Agencies CSV Pack (ZIP):** এক ক্লিকে সব স্টক সাইটের আলাদা আলাদা অফিসিয়াল CSV ফাইল একসাথে ZIP আকারে ডাউনলোড।
   - **Official Prohibited Word Sanitizer:** ক্যামেরার নাম/মডেল (Nikon, Canon, 4K, DSLR), ব্র্যান্ডের নাম এবং `"A photo of"` অটোমেটিক রিমুভ করে।

3. **সকল এন্ড্রয়েড মোবাইলে কার্যকর (Android 5.0 Lollipop থেকে Android 15):**
   - `minSdk 21` থেকে `targetSdk 34` সাপোর্ট।
   - **Native Android Bridge (`window.AndroidBridge`):** ওয়েবভিউতে ডাউনলোড ব্লক হওয়ার সমস্যা নেই; সরাসরি ফোনের `Downloads/CN_META_PRO` ফোল্ডারে CSV ও Embedded JPEG ZIP সেভ হয়।
   - **Multi-File Gallery Picker:** একসাথে শত শত ছবি ও ভিডিও সিলেক্ট করার সুবিধা।

---

## গিটহাব দিয়ে অটোমেটিক APK তৈরি করার নিয়ম (How to Build APK on GitHub)

1. এই প্রজেক্টের ফাইলগুলো আপনার একটি নতুন **GitHub Repository**-তে আপলোড (Push) করুন।
2. গিটহাব রিপোজিটরির **Actions** ট্যাবে যান।
3. সেখানে **"Build CN META PRO Android APK"** ওয়ার্কফ্লো অটোমেটিক চালু হবে (অথবা **Run workflow** বাটনে ক্লিক করুন)।
4. মাত্র ২ মিনিটের মধ্যে বিল্ড সম্পন্ন হলে **Artifacts** অথবা **Releases** সেকশন থেকে **`CN-META-PRO-v4.0-Universal-Signed.apk`** ডাউনলোড করে যেকোনো এন্ড্রয়েড ফোনে ইনস্টল করুন!
